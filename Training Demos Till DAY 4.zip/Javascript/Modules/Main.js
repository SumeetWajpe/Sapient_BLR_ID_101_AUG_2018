
import Multiply,{Add,Subtract} from './Calculator.js';
const PI = 3.14;
console.log('The addition is :' + Add(20,30));
console.log('The product is :' + Multiply(20,30));
