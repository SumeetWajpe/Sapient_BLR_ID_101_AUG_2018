export function Add(x,y){
    return x + y;
}
export function Subtract(x,y){
    return x - y;
}
export default function Product(x,y){
    return x *y
}