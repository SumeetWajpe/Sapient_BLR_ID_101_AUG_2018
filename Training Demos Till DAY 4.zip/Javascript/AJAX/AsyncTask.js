// returns a Promise
// Provider

function ReturnAPromise(){
    return new Promise(function(resolve,reject){
        let xmlhttpReqObj = new XMLHttpRequest();
        xmlhttpReqObj.open('GET',"https://jsonplaceholder.typicode.com/posts");
        xmlhttpReqObj.send(); // makes an ajax call !
        xmlhttpReqObj.onreadystatechange =function(){
            if(xmlhttpReqObj.readyState == 4 && 
            xmlhttpReqObj.status == 200){
                // resolving the promise !
                    resolve(xmlhttpReqObj.responseText)
               }// eof if         
               else if(xmlhttpReqObj.readyState == 4 && 
                xmlhttpReqObj.status != 200){
                    //rejecting a promise !
                            reject(xmlhttpReqObj.statusText);
               } 
            }        
    })
}