
onmessage = function (dataFromMainThread){
    var myArrayData = [];
    console.log(dataFromMainThread.data);
    for(let i=0;i<8000;i++){
        myArrayData[i] = [];
        for(let j = 0;j<5000;j++){
            myArrayData[i][j] = Math.random();
        }
    }

    postMessage(myArrayData);// send the array back to main thread !
}

