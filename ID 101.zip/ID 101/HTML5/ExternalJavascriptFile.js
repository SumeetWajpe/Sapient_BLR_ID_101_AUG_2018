function Emp(){
    this.salary = 100000;
    var self = this;
    setTimeout(function(){
            console.log(self.salary);
    },2000)
}